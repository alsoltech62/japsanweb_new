import React, { useState, useEffect } from 'react';
import toast from 'react-hot-toast';
import { sendAdminNotification, getAdminNotifications, updateAdminNotification, deleteAdminNotification } from '../../services/api';
import { FiSend, FiList, FiEdit2, FiTrash2, FiSearch, FiRefreshCw, FiImage, FiUsers, FiClock, FiX, FiCheck } from 'react-icons/fi';
import { format } from 'date-fns';

export default function AdminNotifications() {
  const [activeTab, setActiveTab] = useState('send'); // 'send' | 'history'
  const [form, setForm] = useState({
    target: 'all',
    title: '',
    message: ''
  });
  const [imageFile, setImageFile] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [loading, setLoading] = useState(false);

  // History State
  const [notifications, setNotifications] = useState([]);
  const [loadingList, setLoadingList] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [targetFilter, setTargetFilter] = useState('all');

  // Edit Modal State
  const [editingItem, setEditingItem] = useState(null);
  const [editForm, setEditForm] = useState({ id: 0, title: '', message: '', target: 'all', image_url: '' });
  const [editImageFile, setEditImageFile] = useState(null);
  const [editImagePreview, setEditImagePreview] = useState(null);
  const [savingEdit, setSavingEdit] = useState(false);

  // Delete Confirm State
  const [deletingId, setDeletingId] = useState(null);

  useEffect(() => {
    if (activeTab === 'history') {
      fetchNotifications();
    }
  }, [activeTab, targetFilter]);

  const fetchNotifications = async () => {
    setLoadingList(true);
    try {
      const res = await getAdminNotifications({ type: targetFilter, search: searchQuery });
      if (res.data?.success) {
        setNotifications(res.data.data?.notifications || []);
      }
    } catch (err) {
      toast.error('Failed to load notifications history');
    } finally {
      setLoadingList(false);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title.trim() || !form.message.trim()) {
      return toast.error("Title and message are required");
    }

    setLoading(true);
    try {
      const formData = new FormData();
      formData.append('target', form.target);
      formData.append('title', form.title.trim());
      formData.append('message', form.message.trim());
      if (imageFile) {
        formData.append('image', imageFile);
      }

      await sendAdminNotification(formData);
      toast.success("Notification sent successfully!");
      setForm({ target: 'all', title: '', message: '' });
      setImageFile(null);
      setImagePreview(null);
      if (activeTab === 'history') fetchNotifications();
    } catch (err) {
      toast.error(err.response?.data?.message || err.message || 'Failed to send notifications');
    } finally {
      setLoading(false);
    }
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        toast.error("Image size must be less than 2MB");
        return;
      }
      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const openEditModal = (item) => {
    setEditingItem(item);
    setEditForm({
      id: item.id,
      title: item.title,
      message: item.clean_message || item.message,
      target: item.target || 'all',
      image_url: item.image_url || ''
    });
    setEditImageFile(null);
    setEditImagePreview(item.image_url ? (item.image_url.startsWith('http') ? item.image_url : item.image_url) : null);
  };

  const handleEditSubmit = async (e) => {
    e.preventDefault();
    if (!editForm.title.trim() || !editForm.message.trim()) {
      return toast.error('Title and message are required');
    }

    setSavingEdit(true);
    try {
      const formData = new FormData();
      formData.append('action', 'edit');
      formData.append('id', editForm.id);
      formData.append('title', editForm.title.trim());
      formData.append('message', editForm.message.trim());
      if (editImageFile) {
        formData.append('image', editImageFile);
      } else if (editForm.image_url) {
        formData.append('image_url', editForm.image_url);
      }

      const res = await updateAdminNotification(formData);
      if (res.data?.success) {
        toast.success('Notification updated successfully!');
        setEditingItem(null);
        fetchNotifications();
      }
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update notification');
    } finally {
      setSavingEdit(false);
    }
  };

  const handleDelete = async (item) => {
    if (!window.confirm(`Are you sure you want to delete notification "${item.title}"?`)) {
      return;
    }

    setDeletingId(item.id);
    try {
      const res = await deleteAdminNotification(item.id);
      if (res.data?.success) {
        toast.success('Notification deleted successfully!');
        fetchNotifications();
      }
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to delete notification');
    } finally {
      setDeletingId(null);
    }
  };

  const filteredHistory = notifications.filter(n => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (n.title || '').toLowerCase().includes(q) || (n.message || '').toLowerCase().includes(q);
  });

  return (
    <div className="space-y-6 fade-in max-w-4xl mx-auto font-sans pb-12">
      {/* Header & Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-black text-slate-800">📢 Notification Manager</h2>
          <p className="text-xs text-slate-500">Broadcast messages, edit existing alerts, or delete sent notifications</p>
        </div>

        <div className="flex items-center bg-slate-100 p-1.5 rounded-2xl border border-slate-200 shrink-0">
          <button
            onClick={() => setActiveTab('send')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'send'
                ? 'bg-white text-orange-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FiSend size={14} /> Send New
          </button>
          <button
            onClick={() => setActiveTab('history')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              activeTab === 'history'
                ? 'bg-white text-orange-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FiList size={14} /> Manage & History ({notifications.length})
          </button>
        </div>
      </div>

      {/* TAB 1: SEND NOTIFICATION */}
      {activeTab === 'send' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-100">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Target Audience</label>
              <select 
                className="input-field"
                value={form.target}
                onChange={e => setForm({...form, target: e.target.value})}
              >
                <option value="all">🌐 All Users & Vendors</option>
                <option value="users">👤 Users (Customers) Only</option>
                <option value="vendors">🏪 Vendors (Store Owners) Only</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Notification Title *</label>
              <input 
                type="text" 
                className="input-field" 
                placeholder="e.g. 🔥 Weekend Special: Get 20% Extra Cashback!" 
                value={form.title}
                onChange={e => setForm({...form, title: e.target.value})}
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Message Body *</label>
              <textarea 
                className="input-field min-h-[120px]" 
                placeholder="Write your announcement or offer details here..." 
                value={form.message}
                onChange={e => setForm({...form, message: e.target.value})}
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">Banner Image (Optional)</label>
              <p className="text-xs text-slate-400 mb-2">Recommended: 16:9 ratio. Supported: JPG, PNG, WEBP (Max 2MB)</p>
              <input 
                type="file" 
                accept="image/*"
                className="input-field text-xs" 
                onChange={handleImageChange}
              />
              {imagePreview && (
                <div className="mt-3 relative inline-block">
                  <img src={imagePreview} alt="Preview" className="max-h-40 rounded-2xl border border-slate-200 shadow-sm object-cover" />
                  <button
                    type="button"
                    onClick={() => { setImageFile(null); setImagePreview(null); }}
                    className="absolute -top-2 -right-2 bg-rose-500 text-white p-1 rounded-full shadow hover:bg-rose-600"
                  >
                    <FiX size={14} />
                  </button>
                </div>
              )}
            </div>

            <button 
              type="submit" 
              disabled={loading}
              className="btn-primary w-full py-3.5 flex items-center justify-center gap-2 text-sm font-bold shadow-lg shadow-orange-500/20"
            >
              {loading ? <span className="animate-spin text-lg">↻</span> : <FiSend size={16} />}
              {loading ? 'Broadcasting Notification...' : '🚀 Send Broadcast Notification'}
            </button>
          </form>
        </div>
      )}

      {/* TAB 2: MANAGE & HISTORY */}
      {activeTab === 'history' && (
        <div className="space-y-4">
          {/* Controls Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-100 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3">
            <div className="relative flex-1 w-full">
              <FiSearch className="absolute left-3.5 top-3 text-slate-400" size={16} />
              <input
                type="text"
                placeholder="Search notification title or message..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-orange-500"
              />
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                value={targetFilter}
                onChange={e => setTargetFilter(e.target.value)}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:border-orange-500"
              >
                <option value="all">All Targets</option>
                <option value="user">Users Only</option>
                <option value="vendor">Vendors Only</option>
              </select>

              <button
                onClick={fetchNotifications}
                className="p-2 text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition"
                title="Refresh"
              >
                <FiRefreshCw size={14} className={loadingList ? 'animate-spin' : ''} />
              </button>
            </div>
          </div>

          {/* List of Sent Notifications */}
          {loadingList ? (
            <div className="space-y-3">
              {[1, 2, 3].map(i => (
                <div key={i} className="h-28 bg-slate-200 rounded-2xl animate-pulse" />
              ))}
            </div>
          ) : filteredHistory.length === 0 ? (
            <div className="bg-white rounded-3xl p-12 text-center border border-slate-100 shadow-sm space-y-3">
              <div className="text-4xl">📭</div>
              <h3 className="font-bold text-slate-800 text-base">No notifications found</h3>
              <p className="text-xs text-slate-500">You haven't sent any notifications matching the current criteria.</p>
              <button
                onClick={() => setActiveTab('send')}
                className="btn-primary text-xs px-4 py-2"
              >
                Send Your First Notification
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredHistory.map((item) => (
                <div
                  key={item.id}
                  className="bg-white rounded-2xl p-5 border border-slate-100 shadow-sm hover:shadow-md transition-all space-y-3"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase ${
                          item.target === 'all' ? 'bg-indigo-100 text-indigo-800' :
                          item.target === 'users' ? 'bg-orange-100 text-orange-800' : 'bg-blue-100 text-blue-800'
                        }`}>
                          {item.target === 'all' ? '🌐 All Users & Vendors' : item.target === 'users' ? '👤 Users' : '🏪 Vendors'}
                        </span>
                        <span className="text-slate-400 text-xs flex items-center gap-1">
                          <FiClock size={12} />
                          {item.created_at ? format(new Date(item.created_at), 'dd MMM yyyy, hh:mm a') : 'N/A'}
                        </span>
                      </div>
                      <h3 className="font-black text-slate-800 text-base">{item.title}</h3>
                    </div>

                    {/* Action Buttons (Edit & Delete) */}
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        onClick={() => openEditModal(item)}
                        className="p-2 text-slate-600 hover:text-blue-600 bg-slate-50 hover:bg-blue-50 border border-slate-200 rounded-xl transition-all"
                        title="Edit Notification"
                      >
                        <FiEdit2 size={14} />
                      </button>
                      <button
                        onClick={() => handleDelete(item)}
                        disabled={deletingId === item.id}
                        className="p-2 text-slate-600 hover:text-rose-600 bg-slate-50 hover:bg-rose-50 border border-slate-200 rounded-xl transition-all disabled:opacity-50"
                        title="Delete Notification"
                      >
                        <FiTrash2 size={14} />
                      </button>
                    </div>
                  </div>

                  <p className="text-xs text-slate-600 whitespace-pre-line leading-relaxed">
                    {item.clean_message || item.message}
                  </p>

                  {/* Thumbnail if image is attached */}
                  {item.image_url && (
                    <div className="pt-2">
                      <img
                        src={item.image_url.startsWith('http') ? item.image_url : (item.image_url.startsWith('/') ? item.image_url : `/${item.image_url}`)}
                        alt="Notification Media"
                        className="max-h-36 rounded-xl border border-slate-200 object-cover shadow-xs"
                      />
                    </div>
                  )}

                  <div className="pt-2 border-t border-slate-50 flex items-center justify-between text-[11px] text-slate-400">
                    <span className="flex items-center gap-1">
                      <FiUsers size={12} /> Recipients: <strong className="text-slate-700">{item.total_recipients || 1}</strong>
                    </span>
                    <span>
                      Read: <strong className="text-emerald-600">{item.read_count || 0}</strong>
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* EDIT NOTIFICATION MODAL */}
      {editingItem && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-2xl border border-slate-100 slide-up max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4 border-b border-slate-100 pb-3">
              <div>
                <h3 className="font-black text-lg text-slate-800">✏️ Edit Notification</h3>
                <p className="text-xs text-slate-500">Update title, message content or banner image</p>
              </div>
              <button
                onClick={() => setEditingItem(null)}
                className="p-2 text-slate-400 hover:text-slate-600 rounded-full"
              >
                <FiX size={18} />
              </button>
            </div>

            <form onSubmit={handleEditSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Title *</label>
                <input
                  type="text"
                  className="input-field text-sm"
                  value={editForm.title}
                  onChange={e => setEditForm({ ...editForm, title: e.target.value })}
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Message Body *</label>
                <textarea
                  className="input-field min-h-[120px] text-sm"
                  value={editForm.message}
                  onChange={e => setEditForm({ ...editForm, message: e.target.value })}
                  required
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Update Banner Image</label>
                <input
                  type="file"
                  accept="image/*"
                  className="input-field text-xs"
                  onChange={e => {
                    const file = e.target.files[0];
                    if (file) {
                      setEditImageFile(file);
                      setEditImagePreview(URL.createObjectURL(file));
                    }
                  }}
                />
                {editImagePreview && (
                  <div className="mt-2 relative inline-block">
                    <img src={editImagePreview} alt="Preview" className="max-h-32 rounded-xl border border-slate-200" />
                    <button
                      type="button"
                      onClick={() => { setEditImageFile(null); setEditImagePreview(null); setEditForm({...editForm, image_url: ''}); }}
                      className="absolute -top-2 -right-2 bg-rose-500 text-white p-1 rounded-full shadow hover:bg-rose-600"
                    >
                      <FiX size={12} />
                    </button>
                  </div>
                )}
              </div>

              <div className="pt-3 flex gap-3">
                <button
                  type="button"
                  onClick={() => setEditingItem(null)}
                  className="btn-secondary flex-1"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={savingEdit}
                  className="btn-primary flex-1 flex items-center justify-center gap-1.5"
                >
                  {savingEdit ? 'Saving Changes...' : 'Save & Update'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

